
1. These instructions assume you already have a domain name, free or paid, and have it registered with a DNS to point to your new server install. 
1. If you have no idea what that last sentence was talking about you can get a general idea by going [here](https://www.dnsexit.com/Direct.sv?cmd=dynDns). You can choose to use this service or one of many, many others but either way the page gives a fair explanation of how the services work. 

The main benefit of using Caddy (especially for Windows users) is automatic HTTPS.

# Install Caddy Server on Windows

1. Head over to [Caddy's download page](https://caddyserver.com/download)
1. select the add plugins option and select http.reauth, then select done. 
1. Click the download button. Sometime is takes a moment to begin the download as the exe is compiled with your plugin before it begins.  
1. Create a folder on your system drive named Caddy (ex: C:\Caddy)
1. extract the contents of the downloaded archive to that folder 

![C:\Caddy Screenshot](http://i.imgur.com/QQNSo6y.jpg)

## Install PHP

1. Head over to [http://windows.php.net/download](http://windows.php.net/download)
1. Extract the contents of the downloaded zip to a folder called php 
1. Place the newly created php folder in  your C:\Caddy directory
1. Rename php.ini-development or php.ini-production to just php.ini
1. Open the ini in your favorite text editor and remove the ; from the front of the following statements. What each function is used for is outlined [here](https://github.com/causefx/Organizr/wiki). You can leave some off if 
 you don't plan to use those features.
```
;extension=php_pdo_sqlite.dll
;extension=sqlite3 (can be php_sqlite3.dll on older php installations)
;extension=openssl (can be php_openssl.dll on older php installations)
;extension=curl (can be php_curl.dll on older php installations)

```
## Make a root directory for the web server

1. Create a  folder inside C:\Caddy and name it www
1. This folder will be the location where all of the web site files will live, 
having these files seperated just makes things a bit cleaner and reduces confusion once the folders get more files in them. 

## Make a caddyfile
The caddyfile is a config file that caddy reads on startup in order to determine how to direct users to your pages. 
(newer versions of Caddy Server also allow an additional file called common.conf which can be called from the caddyfile
for more versitility but we will not use them both at this stage)

1. Using a text editor ([Notepad++ Recommended](https://notepad-plus-plus.org/download/v7.4.2.html)) create a file called 
   "caddyfile" (there is no extension) inside C:\Caddy

   Note- Windows defaults to hiding extensions, if you can open the file without having to select a program then it's 
   likely not the way it needs to be as the extension is probably just hidden.
1. Copy the below into your caddyfile then save the file. 
```
domain.com {  #replace domain.com with your site 
 
# The below listed starup command opens php when you open Caddy Server
  startup /caddy/php/php-cgi -b 127.0.0.1:9000 &
 
# Sets the root folder for your website
  ext .html .htm .php
  root /caddy/www
  
  gzip

# This is an example for accessing sonarr at http://domain.com/sonarr but 
# can be modified for many other similar services. Remember you have a setting in these
# apps where you tell it where the proxy is located for it to be able to find resources. 
# In this case that blank would be filled in with /sonarr

  proxy /sonarr 127.0.0.1:8989 {
    transparent
  }
 
}
 
#localhost block, typically this would have a duplicate of the above listed sites but this 
#will remain blank in this config since it will be better filled later by using common.conf
 
http://localhost {

  ext .html .htm .php
  root /caddy/www
  
  gzip
 
}
 
# this block would also access sonarr service but would do so as http://sonarr.domain.com
# This option also requires additional steps at the DNS level to make sure sonarr.domain.com points at this server.
# If this option is used in place of the above version there is no need to fill in the proxy setting as outlined above
# If that setting remains then the site would not work as expected.

### Remove the # at the begninning of the lines below to use this option
# sonarr.domain.com {
#  gzip
# 
#  proxy / 127.0.0.1:8989 {
#    transparent
#  }
#}
 
```
## Make a generic web page

1. Before we set up Organizr we need a test html to prove Caddy is working. 
1. Create a file called index.html and type anything you want into the file. Just plain text as a message to yourself. 
1. Place your index.html file in the c:\Caddy\www folder

## Test Caddy

1. Double click caddy.exe, if this is the first run Caddy will prompt you to provide a recovery email address for certificate recovery if required.
1. you may or may not have to reopen caddy once this portion is complete.
1. you should see a command window open that shows the URL for your website in a few different forms once caddy is ready to work. (if the windows open then immediatly closes you may need to run it from a command window in order to read the error message)
1. On the server computer, open a browser and type localhost in the address bar. Did your personal message show up in the broswer? Yay! It works. 
1. Next test, on a seperate network (a cell phone without wifi enabled would work) navigate to yourdomain.com. You should see your message again assuming your server, windows firewall, router port forwarding, and DNS are set up correctly. 

## Installing Organizr

1. [Download](https://github.com/causefx/Organizr/releases) the lastest release of Organizr
1. Extract the contents of the Organizr 1.xx folder into a new folder named Organizr located at C:\Caddy\www

## Testing Organizr

Navigate to yourdomain.com/organizr from the external device (phone?) and you should have an Organizr loading screen. 

___

## Server Authentication using http.reauth

[http.reauth](https://github.com/freman/caddy-reauth) is a plug in for caddy that allows you to use the internal auth.php file in Organizr to authenticate users who are or are not allow to view web pages present on your server.(All thanks goes to user freman for [tweaking his code to allow this](https://github.com/freman/caddy-reauth/issues/1))

add the following lines to your existing caddyfile/common.conf as required. 
```
my-domain{
   # This code allows your browser/server to look at Organizr and verify if the currently logged in user's status is 
   # admin, user, or neither. This is based on assigned group in Organizer's "Manage users" tab
   # Admin allows users to see Admin, User, and guest pages
   # User allows a user to see User and Guest pages. 
   # Guest pages should not be assigned to either of these options.
   # each page should only be present in ONE of the blocks if auth is required.
	
   # this is where the protection happens. there is one call for users and one for admins
	reauth {
		path /sonarr   # protect what i have set a proxy to be called /sonarr
             #  path /radarr   # other directories can be listed
             #  path /sabnzbd
   # if someone is not authorized for a page, send them here instead of allowing 
   # them through to the intended page
                failure redirect target=https://my-domain.com/organizr
   # The above listed directories with be pretected from anyone not listed in Organizr as an Admin
		upstream url=https://my-domain.com/Organizr/auth.php?admin,cookies=true
	}
	
	reauth {
		path /ombi
              # path /otherStuff # other directories can be listed as required
                failure redirect target=https://my-domain.com/organizr
   # This bracket does the same as the above annotated bracket but the minimum required group is User
		upstream url=https://my-domain.com/auth-user,cookies=true
	}

## pre existing caddyfile code continued here

}

## Using a sub domain. 
plexpy.my-domain.com {

	reauth {
		path /  #you want to protect the entire subdomain
                failure redirect target=https://my-domain.com/organizr
    # Since each subdomain requires a separate instance of the reauth{} you must change the below line 
    # for admin or user as necessary
		upstream url=https://my-domain.com/Organizr/auth.php?user,cookies=true
	}
}

```
Now you should be able to limit access to pages based on the current status of Organizr log in. The proxy listed in on whichever list will limit access to only those users currently logged into Organizr and with a minimum user group of the specified type. 
___ 

If you see issues with 502 gateway errors then see [here](https://github.com/causefx/Organizr/issues/390) for the solution

More information on the caddyfile here [https://caddyserver.com/docs/http-caddyfile](https://caddyserver.com/docs/http-caddyfile)

If you will have many services running behind Caddy this would be a good staring point for a more detailed [caddyfile](https://pastebin.com/bLVJ4vsN) and [common.conf](https://pastebin.com/hdDKbcSV) file. 

