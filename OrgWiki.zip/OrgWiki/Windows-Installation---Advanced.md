# Windows Installation
## Basic Windows Installation
This guide assumes that you have some experience using/or are capable of learning how to host a webserver such as Apache, NGINX, Caddy etc. If not we suggest you read up on at least one of them. This guide is built around using a precompiled web development suite called WPN-XM as it includes all of the dependencies needed to create a Basic Windows Installation for Organizr to run on an NGINX webserver.

What this guide will not show you, is how to install other programs into your, how to create an SSL certificate

### Dependencies
* [WPN-XM Standard Install](http://wpn-xm.org/downloads.php) (includes PHP 5.5 or 5.6 and NGINX)
* A Dynamic DNS Domain
    * Free Examples: [No-IP.com](http://no-ip.com), [Afraid.org](http://afraid.org)
    * Paid Example: [Namecheap.com](http://Namecheap.com)
*Optional: An SSL certificate - I highly suggest the AdvancedDNS provided by Namecheap.com as part of a private hosting, their verification was quite painless. - Sample NGINX profile is for SSL.

*Optional: Private SMTP mail service (I use the private paid email by Namecheap.com)

### Step 1: Server and Organizr Installation
1. Download and install [WPN-XM Standard Install](http://wpn-xm.org/downloads.php) to the root of your Hard Drive (ex. C:\WPNXM)
1. Navigate to C:\WPNXM\bin\php
1. Open\Edit the php.ini file with your favorite text editor (ex. Notepad++) I highly recommend NOT using the stock text editor in Windows.
    1. Remove the ; in front of ";extension=php_pdo_sqlite.dll" to make it "extension=php_pdo_sqlite.dll" (Appx. line 883)
    1. Remove the ; in front of "; sqlite3.extension_dir =" and add "ext" to make it "sqlite3.extension_dir = ext"
1. Establish a project folder within C:\WPNXM\www\"your project name" | (ex. C:\WPNXM\www\organizr)
1. Download the latest Master branch from [Organizr's Github](https://github.com/causefx/Organizr)
1. Extract the inner contents of the Organizer-master.zip you just downloaded (Organizr-master.zip\Organizer-Master\!EXTRACT THIS FILE STRUCTURE!) to your project folder that you created (ex. C:\WPNXM\www\organizr)

### Step 2: Generate and Verify your SSL certificate for NGINX - I will not be going into detail on this topic
This can be very confusing if you have never done so before - Google is your friend and so is trial and error
1.  WPN-XM has openssl pre-installed - navigate to C:\WPNXM\bin\openssl to use its functions

The following links were instrumental in creating an SSL cert:

*    [Namecheap.com - How do I activate an SSL certificate](https://www.namecheap.com/support/knowledgebase/article.aspx/794/67/how-do-i-activate-an-ssl-certificate)
*    [SSL with a Reverse Proxy (NGINX) and Usenet Services](https://blog.jagandeepbrar.io/ssl-with-a-reverse-proxy-nginx-and-usenet-services-f98fa6fb7f4b#.ho38g648b)

Note: I recommend HTTP verification, and understand that you do need to have access to your domains e-mail in order to fully register your SSL cert.

### Step 3: Configure NGINX and start your server
1.  Navigate to "C:\WPNXM\bin\nginx\conf\domains-enabled" and create a config file (Ex. server.conf)
    1. This will automatically be called by the stock nginx.conf in the bin folder. Please only create new configs in this folder
2.  The sample below includes reverse proxies as well as SSL for some popular usenet services, feel free to change the config to suit your needs:

>     #
>     # HTTPS server
>     # Addtional notes on how to convert to HTTP config commented
>     #
>     # Nginx Server Setup Example
>     # for SSL with TLS and a few good ciphers
>     #
>
>     server {
>     listen 443 default_server ssl;  # delete "ssl" and change listen port to "80" from (ex. "443") for non SSL
>     server_name server.com ;
>     
>     ## Root and index files.
>     root www/server; ## the www/server folder can be named www/whatever  and is the root file for your website located at "C:\WPNXM\www"
>     index  index.php index.html index.htm;    
>     
>     # certs sent to the client in SERVER HELLO are concatenated in ssl_certificate
>     ssl_certificate      ../../../bin/openssl/certs/SSL-Bundle.crt; # comment this out for no SSL 
>     ssl_certificate_key  ../../../bin/openssl/certs/unencrypt.key; # comment this out for no SSL 
>     ssl_session_timeout 5m; # comment this out for no SSL 
>     ssl_session_cache shared:SSL:50m; # comment this out for no SSL 


>     # TLS
>     ssl_protocols TLSv1.1 TLSv1.2; # comment this out for no SSL 
>     ssl_ciphers 'ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:DHE-DSS-AES128-GCM-SHA256:kEDH+AESGCM:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-DSS-AES128-SHA256:DHE-RSA-AES256-SHA256:DHE-DSS-AES256-SHA:DHE-RSA-AES256-SHA:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!3DES:!MD5:!PSK'; # comment this out for no SSL 
>     ssl_prefer_server_ciphers on; # comment this out for no SSL 

>     # HSTS (required: ngx_http_headers_module) (max-age 6 months)
>     add_header Strict-Transport-Security max-age=15768000; # comment this out for no SSL 

>     # OCSP Stapling ---
>     # fetch OCSP records from URL in ssl_certificate and cache them
>     ssl_stapling on; # comment this out for no SSL 
>     ssl_stapling_verify on; # comment this out for no SSL 

>     ## verify chain of trust of OCSP response using Root CA and Intermediate certs
>     ssl_trusted_certificate /WPNXM/bin/openssl/certs/SSL-Bundle.crt; # comment this out for no SSL 

>     # ....
>         ## If no favicon exists return a 204 (no content error).
>         location = /favicon.ico {
>         try_files $uri =204;
>         log_not_found off;
>         access_log off;
>         }
>         
>         ## Don't log robots.txt requests.
>         location = /robots.txt {
>         allow all;
>         log_not_found off;
>         access_log off;
>         }

>         ##pass the PHP scripts to FastCGI server listening on 127.0.0.1:9100
>         
>         location ~ \.php$ {
>             try_files      $uri =404;
>             fastcgi_param  HTTPS on; ## comment out this line for no HTTPS
>             fastcgi_pass   php;
>             fastcgi_index  index.php;
>             fastcgi_param  SCRIPT_FILENAME  $document_root$fastcgi_script_name;
>             fastcgi_param  REMOTE_ADDR $http_x_real_ip;
>             include        fastcgi_params;
>         }
>     ###Insert all Reverse Proxies Here###
>         location /sonarr {
>         #include C:/WPNXM/bin/nginx/conf/cookie_direct_blocking.conf;
>             proxy_pass http://127.0.0.1:8989;
>             proxy_set_header Host $host;
>             proxy_set_header X-Real-IP $remote_addr;
>             proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
>             }     
>         location /mylar {
>         #include C:/WPNXM/bin/nginx/conf/cookie_direct_blocking.conf;
>             proxy_pass http://127.0.0.1:8090;
>             proxy_set_header Host $host;
>             proxy_set_header X-Real-IP $remote_addr;
>             proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
>             }   
>         location /lazy {
>         #include C:/WPNXM/bin/nginx/conf/cookie_direct_blocking.conf;
>             proxy_pass http://127.0.0.1:5299;
>             proxy_set_header Host $host;
>             proxy_set_header X-Real-IP $remote_addr;
>             proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
>             }
>         location /plexpy {
>         #include C:/WPNXM/bin/nginx/conf/cookie_direct_blocking.conf;
>             proxy_pass http://127.0.0.1:8181;
>             proxy_set_header Host $host;
>             proxy_set_header X-Real-IP $remote_addr;
>             proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
>             }
>         location /nzbget {
>         #include C:/WPNXM/bin/nginx/conf/cookie_direct_blocking.conf;
>             proxy_pass http://127.0.0.1:6722;
>             proxy_set_header Host $host;
>             proxy_set_header X-Real-IP $remote_addr;
>             proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
>             }
>         location /nzbhydra {
>         #include C:/WPNXM/bin/nginx/conf/cookie_direct_blocking.conf;
>             proxy_pass http://127.0.0.1:5075;
>             proxy_set_header Host $host;
>             proxy_set_header X-Real-IP $remote_addr;
>             proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
>             }
>         location /ombi {
>         #include C:/WPNXM/bin/nginx/conf/cookie_direct_blocking.conf;
>             proxy_pass http://127.0.0.1:3579;
>             proxy_set_header Host $host;
>             proxy_set_header X-Real-IP $remote_addr;
>             proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
>             }
>         location /radarr {
>         #include C:/WPNXM/bin/nginx/conf/cookie_direct_blocking.conf;
>             proxy_pass http://127.0.0.1:7878;
>             proxy_set_header Host $host;
>             proxy_set_header X-Real-IP $remote_addr;
>             proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
>             }
>      

>     }

## Optional: Enable Mail Sending

To enable the sending of e-mail via an **SMTP server** (my example uses private email by namecheap):

1.  Navigate to C:\WPNXM\bin\php
1.  Open\Edit the php.ini file with your favorite text editor (ex. Notepad++) I highly recommend NOT using the stock text editor in Windows.
1.  Search for \[mail function] (Appx. Line 998) and comment out (add ; at the beginning of each line) everything EXCEPT: "sendmail_path = " define this as "sendmail_path = C:\WPNXM\bin\sendmail\sendmail.exe-t" and "mail.add_x_header = on" (this should be default).
1.  Navigate to C:\WPNXM\bin\sendmail and open sendmail.ini with your favorite text editor (ex. Notepad++) I highly recommend NOT using the stock text editor in Windows.
    1. Delete everything in sendmail.ini and replace with the following code block (Ensure you make the edits noted in bold):

**DO NOT ADD ANYTHING ELSE TO THIS, ADDING MORE IS NOT BETTER IN THIS SITUATION**

> >     ; configuration for fake sendmail

> >     ; if this file doesn't exist, sendmail.exe will look for the settings in
> >     ; the registry, under HKLM\Software\Sendmail

> >     [sendmail]

> >     ; you must change mail.mydomain.com to your smtp server,
> >     ; or to IIS's "pickup" directory.  (generally C:\Inetpub\mailroot\Pickup)
> >     ; emails delivered via IIS's pickup directory cause sendmail to
> >     ; run quicker, but you won't get error messages back to the calling
> >     ; application.

> >     smtp_server=**mail.privateemail.com ** <-- This is namecheaps private e-mail, input your own server name
 
> >     ; smtp port (normally 25)

> >     smtp_port= **465** <-- This is namecheaps private e-mail port for SSL
> >     debug_logfile=debug.log

> >     ; SMTPS (SSL) support
> >     ;   auto = use SSL for port 465, otherwise try to use TLS
> >     ;   ssl  = alway use SSL
> >     ;   tls  = always use TLS
> >     ;   none = never try to use SSL

> >     smtp_ssl=ssl

> >     ; the default domain for this server will be read from the registry
> >     ; this will be appended to email addresses when one isn't provided
> >     ; if you want to override the value in the registry, uncomment and modify

> >     ;default_domain=mydomain.com

> >     ; log smtp errors to error.log (defaults to same directory as sendmail.exe)
> >     ; uncomment to enable logging

> >     error_logfile=error.log

> >     ; create debug log as debug.log (defaults to same directory as sendmail.exe)
> >     ; uncomment to enable debugging

> >     ;debug_logfile=debug.log

> >     ; if your smtp server requires authentication, modify the following two lines

> >     auth_username=**admin@yourserver.com ** <-- input your SMTP servers username
> >     auth_password= **(Your password)** <-- input your SMTP servers password

> >     ; if your smtp server uses pop3 before smtp authentication, modify the 
> >     ; following three lines.  do not enable unless it is required.

> >     pop3_server=
> >     pop3_username=
> >     pop3_password=

> >     ; force the sender to always be the following email address
> >     ; this will only affect the "MAIL FROM" command, it won't modify 
> >     ; the "From: " header of the message content

> >     force_sender=

> >     ; force the sender to always be the following email address
> >     ; this will only affect the "RCTP TO" command, it won't modify 
> >     ; the "To: " header of the message content

> >     force_recipient=

> >     ; sendmail will use your hostname and your default_domain in the ehlo/helo
> >     ; smtp greeting.  you can manually set the ehlo/helo name if required

> >     hostname=

