# Enable Emby Authentication 

1. Go to Settings > Advanced Settings > Authentication tab
2. 'Which databases should be used to allow login' = Organizr Plus Other
3. 'Select backend to use' = Emby Local | Emby Connect | Emby All

      1. **Emby Local** Allow only Local Emby Accounts
      2. **Emby Connect** Allow all Emby Friends Accounts
      3. **Emby All** Allow all Local and Friends Accounts
4. 'Create Accounts As Needed' = leave it with the default value
5. Enter your Emby Host URL Path and API token
6. Save
