# Docker Installation

The good folks over at [LinuxServer.io](https://linuxserver.io) have a Docker Container published for easy setup and use!

## Docker Container Images

Its best if you are already a bit familiar with Docker, have it installed, etc.
And, they have Organizr available in three flavors:

* [x86-64 aka Desktop](https://hub.docker.com/r/lsiocommunity/organizr/)
* [ARMHF](https://hub.docker.com/r/lsioarmhf/organizr/)
* [aarch64 or ARM64](https://hub.docker.com/r/lsioarmhf/organizr-aarch64/)

Please, go view their instructions to have Organizr run on a Docker Container!