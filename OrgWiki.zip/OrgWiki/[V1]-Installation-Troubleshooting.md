# Installation Troubleshooting
## Requirement Checker
Before proceeding, you can open up `check.php` in your browser to see where the problem may be.

## Common Errors
### Fatal error: Uncaught PDOException: could not find driver
You need to install PDO & PDO_SQLITE for php.
 * **WINDOWS:** un-comment this line `;extension=php_pdo_sqlite.dll` in the file `php.ini` 
 * **LINUX:** Install PHP Sqlite in the CLI using the following:
  * PHP5 -> Run `sudo apt-get install php5-sqlite`
  * PHP7 -> Run `sudo apt-get install php7.0-sqlite`
 * **Synology** Using WebStation, Make sure sqlite3 and pdo_sqlite are checked under Extensions.

***
### Fatal error: Uncaught exception 'PDOException' with message 'SQLSTATE[HY000] [14] unable to open database file
You need to have the correction permission for all the files.  Depending on where you saved your .db file, this will determine which directories you need to fix the permissions on.
 * **WINDOWS:** Set your permissions on to `Full Control` for `Everyone `for your directories 
 * **LINUX:** Run `sudo chown -R www-data:www-data /path/to/Organizr`
 * **Synology** 
  1. Open web folder using "File Station"
  2. Right click organizr folder to bring up menu
  3. Select "Properties" from the menu
  4. Select "Permission" tab at the top
  5. Click "Create" button
  6. Open "User or group" drop down menu and select "http"
  7. Tick both "Read" and "Write" in the bottom "Permission" box
  8. Click OK
  9. Tick the box for "Apply to this folder, sub-folders, and files"
  10. Click OK