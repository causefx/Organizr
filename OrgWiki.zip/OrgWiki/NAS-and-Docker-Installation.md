# **Table Of Contents**
* [Docker](#installing-on-docker-systems)
* [Synology](#synology)
* [FreeNAS](#freenas)

# Installing on Docker systems

## Images

Its preferred if you are already a bit familiar with Docker, have it installed, etc.

### [DockerHub](https://hub.docker.com/r/organizrtools/organizr-v2/)

Currently in these variants:
* x86-64 aka Desktop
* ARMHF

### Example Installation

```
docker create \
  --name=organizr \
  -v <path to data>:/config \
  -e PGID=<gid> -e PUID=<uid>  \
  -p 80:80 \
  organizrtools/organizr-v2
```

# Installing on NAS Devices
## Synology

### Step 1: Installing and configure Nginx


1. Install package "Web Station" for DSM

2. Open WebStation, choose "Generals settings" Tab, in Primary Http server choose "Nginx"


### Step 2: Configure PHP


1. In "General settings" Tab choose PHP with PHP 7.0 version.

2. In "PHP settings" Tab activate the cache for PHP 7.0 

3. Activate extension for: curl, Openssl, pdo_sqlite, sqlite3, zip


### Step 3: Installing Organizr


1. Download the last version of Organizr on github

2. Download the latest version in the folder you had create for the "web station" package (web)

3. Give a name to your new folder in web like "Organizr" and change the owner in properties for "http".


### Step 4: Create vhost


1. In the "web station" package on dsm choose the "Virtualhost" Tab.

2. Create a new one and choose "name or port" for him.

3. Give him a root directory like (web/organizr)

4. Choose Nginx and PHP 7.0 for the Primary HTTP server and for PHP field.

### Access "Organizr"

Now you can access to Organizr with the ip adress of your Synology and the port you defined before. (ex: "http://192.168.1.15:5178")
***

## FreeNAS
### 1. Preparing the Jail
We need to get a jail up and running that can host Organizr. In the current version of FreeNAS (11.1), the best method of accomplishing this is through using iocage CLI. In future versions of FreeNAS, this step shouldn't change, as long as FreeNAS still uses iocage.
```
iocage create --basejail --release=11.1-RELEASE --name=Organizr bpf=yes vnet=on dhcp=on boot=on
```
Afterwards, we must enter the jail to install the required packages and allow them to run at boot.
```
iocage exec Organizr
pkg install -y nano nginx git php72 php72-curl php72-pdo php72-sqlite3 php72-simplexml php72-zip php72-openssl curl php72-hash php72-json php72-session php72-pdo_sqlite php72-filter
sysrc nginx_enable=YES
sysrc php_fpm_enable=YES
cd /usr/local/www
git clone -b v2-develop https://github.com/causefx/Organizr
chown -R www:www /usr/local/www/
```

### 2. Setup PHP
Edit php-fpm.conf and php.ini to enable the required settings.
```
echo 'listen = /var/run/php-fpm.sock' >> /usr/local/etc/php-fpm.conf
echo 'listen.owner = www' >> /usr/local/etc/php-fpm.conf
echo 'listen.group = www' >> /usr/local/etc/php-fpm.conf
echo 'listen.mode = 0660' >> /usr/local/etc/php-fpm.conf
cp /usr/local/etc/php.ini-production /usr/local/etc/php.ini
sed -i -e 's/;cgi.fix_pathinfo=1/cgi.fix_pathinfo=0/g' /usr/local/etc/php.ini
sed -i -e 's/;date.timezone =/date.timezone = "Universal"/g' /usr/local/etc/php.ini
```

### 3. Setup Nginx
Delete Nginx's original generic configuration file and replace it. This new config file found below has the bare minimum required to allow Organizr to run.
```
rm /usr/local/etc/nginx/nginx.conf
nano /usr/local/etc/nginx/nginx.conf
```
Paste in the following:
```
user  www;
worker_processes  auto;

events {
    worker_connections  1024;
}

http {
    include       mime.types;
    default_type  application/octet-stream;
    sendfile        on;
    keepalive_timeout  65;

    server {
        listen       80;
        server_name  localhost;

        root   /usr/local/www/Organizr;
       
        location / {
            index  index.php index.html index.htm;
        }

        error_page   500 502 503 504  /50x.html;
        location = /50x.html {
            root   /usr/local/www/nginx-dist;
        }
     
        location ~ \.php$ {
            fastcgi_split_path_info ^(.+\.php)(/.+)$;
            fastcgi_pass unix:/var/run/php-fpm.sock;
            fastcgi_index index.php;
            fastcgi_param SCRIPT_FILENAME $request_filename;
            include fastcgi_params;
        }
    }
}
```

### 4. Completion
Start the required services.
```
service php-fpm start
service nginx start
```
Type `ifconfig` to determine your IP address, then type that IP address into a browser to begin the setup wizard for Organizr V2. Congratulations! 
