# Fail2Ban Config for Organizr on Ubuntu 16.04
### Thank you elmerfdz for the write up.

### Prerequisites: 
* Fail2ban installed and configured.

***


## Create organizr-auth.conf file in the filter.d folder @ /etc/fail2ban/filter.d 

### fail2ban filter configuration for Organizr

    [Definition]
    failregex = ","username":"\S+","ip":"<HOST>","auth_type":"bad_auth"}
    ignoreregex =

### fail2ban filter configuration for Organizr-V2

```
[Definition]
failregex = ","username":"\S+","ip":"<HOST>","auth_type":"error"}*
ignoreregex =
```

###  DEV NOTES:
* Based on fail2ban filter configuration for nginx
* Author: rix1337
* 
* 29.04.18 - Added "fix" for OrganizrV2 failed login line:
* Example log line: ```date":"2018-03-09 10:28:57","username":"[username]","ip":"1.2.3.4","auth_type":"error"},{" ```
* Last two characters (`{"`) are supposed to be on the next line, until then fail2ban regex can be adjusted.
* Author: ndom91
***


## Add Organizr jail config to your jail.local file @ /etc/fail2ban

    [organizr-auth]
    enabled = true
    port = http,https
    filter = organizr-auth
    logpath = /var/www/html/loginLog.json

`logpath = /var/www/html/loginLog.json` = path to Organizr logs
***


## Restart Fail2Ban

`sudo service fail2ban restart`

***

## Docker
Because the Organizr container only logs the docker IP addresses e.g 172.17.0.2 you need to add this in the Organizr default nginx site file.
Go to appdata\organizr\nginx\site-confs\default and add:

```
# get real IP
real_ip_header X-Forwarded-For;
set_real_ip_from 172.17.0.0/16;
real_ip_recursive on;
```
Then restart the container

***

Thanks to rix1337 for the fail2ban config:
* [organizr-auth.conf](https://github.com/rix1337/docker-organizr/blob/master/root/etc/fail2ban/filter.d/organizr-auth.conf)
* [jail.local](https://github.com/rix1337/docker-organizr/blob/master/root/defaults/jail.local)