**Note:** Plex SSO doesn't work on a subdomain i.e. plex.domain.com, you would need to setup Plex as a sub-directory on Nginx i.e. domain.com/plex. To do that, use the following Nginx config for plex, replace 'PlexIP' and don't tweak anything else:

## **Part 1: Nginx setup**

```
        location /plex/ {
            proxy_pass http://PlexIP:32400/;
            include config/proxy.conf;
        }
        if ($http_referer ~* /plex/) {
            rewrite ^/web/(.*) /plex/web/$1? redirect;
        }  
```
Contents of the above included proxy.conf file
```
client_max_body_size 10m;
client_body_buffer_size 128k;
proxy_bind $server_addr;
proxy_buffers 32 4k;
#Timeout if the real server is dead
proxy_next_upstream error timeout invalid_header http_500 http_502 http_503;
# Advanced Proxy Config
send_timeout 5m;
proxy_read_timeout 240;
proxy_send_timeout 240;
proxy_connect_timeout 240;
proxy_hide_header X-Frame-Options;
# Basic Proxy Config
proxy_set_header Host $host:$server_port;
proxy_set_header X-Real-IP $remote_addr;
proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
proxy_set_header X-Forwarded-Proto https;
proxy_redirect  http://  $scheme://;
proxy_http_version 1.1;
proxy_set_header Connection "";
proxy_no_cache $cookie_session;
proxy_set_header Upgrade $http_upgrade;
proxy_set_header Connection "upgrade";
```
After you've added the above, go to domain.com/plex and see if Plex loads up for you, if it does, you've completed part 1 successfully.

## Part 2: Organizr setup

There are 2 ways to do this, if the 1st method doesn't work for you, try the other.

### Method 1. Using full URL for the Plex tab

**a) Edit tabs page [Settings > Edit Tabs]**

![](https://i.imgur.com/q311L2U.png)

_Tab Name = Plex_

_Tab URL  = https://domain.com/plex_

**b) Plex Homepage Settings [Settings > Edit Homepage > Plex]**

![](https://i.imgur.com/jsQJMo7.png)

_Plex URL      = http://YourLocalPlexIP:32400_

_Plex Token    = Click on 'GET PLEX TOKEN'_

_Plex Tab Name = plex_

_Plex Tab URL  = https://domain.com/plex_

### Method 2. Using only the base URL i.e /plex
**Note:** Use this only if method 1 didn't work for you

**a) Edit tabs page [Settings > Edit Tabs]**

![](https://i.imgur.com/cy42wL6.png)

_Tab Name = Plex_

_Tab URL  = /plex_

**b) Plex Homepage Settings [Settings > Edit Homepage > Plex]**

![](https://i.imgur.com/lB7wmsa.png)

_Plex URL      = http://YourLocalPlexIP:32400_

_Plex Token    = Click on 'GET PLEX TOKEN'_

_Plex Tab Name = plex_

_Plex Tab URL  = /plex_

