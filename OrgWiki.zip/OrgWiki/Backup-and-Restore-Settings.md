## Backups
1. The webUI can create a timestamped zip file of all the relevant files needed for backup. Settings -> Advanced -> Save Icon -> BACKUP NOW. This file will be created in /database/backups/ . This is a manual process that requires the user to press the button and also copy the backup file to a safe location. 
2. If you want automated backups made via a third party backup application, you need to backup the following files:
* in /database you need: org.log, loginLog.json and users.db
* in /www/Dashboard/config you need config.php

If you use a backup application, you can have it make incremental backups for the above 4 files automatically.

## Restore from Backup
1. Install Organizr as you would normally
2. Copy the above 4 files into their correct location, overwriting the existing files. 
3. Restart the docker (or process if not in docker) and refresh the web page for Organizr