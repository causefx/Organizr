# Optional Homepage

First, create a tab with the URL `homepage.php`.

You can use whatever name you want for the tab, and I like to use the `images/organizr-load-w-thick.gif` for the icon URL.

And, I have it set as `Default`

Hit `Save Tabs`, and head to `Edit Homepage`

### Homepage settings

Organizr is built to be able to access your:

* `Plex Server`
* `Emby`
* `Sonarr`
* `Radarr`
* `SickBeard`/`SickRage`
* `Headphones`
* `SabNZBD`
* `NZBGet`

At a deeper level than just displaying the webpage within an I Frame. Therefore, filling out each Application's Requested Information greatly expands on Organizr's abilities.

So go through each item, fill out the apps you use!

You'll also notice at the top of each item is a Drop Down item that, if untouched, says `None`. This is to specify the level of authentication needed for a specific user-type to be able to see the information on the Home Page.

So, if you select `None`, then anyone can see that specific info on the HomePage Tab. `User` is for all `Users`, and `Admin` is only for `Admins`

#### Plex Settings

Here, we'll layout Plex's info, as the `Plex Token` part is a bit more of an obscure item.

* **Plex URL** - Plex location, ie. `http://127.0.0.1/` or `http://localhost/`
* **Plex Port** - The local port, ie. `32400`
* **Plex Token** - [Find your X-Plex-Token](https://support.plex.tv/hc/en-us/articles/204059436-Finding-an-authentication-token-X-Plex-Token)
