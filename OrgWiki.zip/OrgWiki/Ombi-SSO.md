## **Part 1: Nginx setup**
Use the following Nginx config for Ombi, replace 'OmbiIP' and don't tweak anything else:

```
 location /ombi {		
     return 301 $scheme://$host/ombi/;		
}
location /ombi/ {
    proxy_pass http://OmbiIP:5000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Host $server_name;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Ssl on;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout  90;
    proxy_redirect http://OmbiIP:5000 https://$host;
}
```

## **Part 2: Organizr**

For SSO to work you need to update Organizr to 1.6

Add your ombi tab with either `https://domain.com/ombi`, `/ombi` or `https://ombi.domain.com/auth/cookie` if you use sub-domain.

After you have done that, go to:

1. Homepage Settings
2. Ombi settings
3. Set your minimum auth level
4. Add your Ombi URL e.g `http://OmbiIP:5000` or `http://OmbiIP:5000/ombi`
5. Add your Ombi API key (Found in Ombi Settings: Settings -> Ombi)
5. Press Save

![](https://technicalramblings.com/wp-content/uploads/2017/11/orgsettings.png)


## **Select database**

Remember to select the Plex database and Plex backend.

We recommend adding an extra admin account that is not tied to Plex.

![](https://i1.wp.com/technicalramblings.com/wp-content/uploads/2017/11/chrome_2018-01-27_17-50-56.png?resize=1024%2C510&ssl=1)