# Organizr Authentication

***
### User Authentication
**Organizr** creates an SQLite database to store user information in a location determined by the admin upon installation.

[**Plex**](https://github.com/causefx/Organizr/wiki/Plex-Authentication) - Use Plex to authenticate users on Organizr

[**Emby**](https://github.com/causefx/Organizr/wiki/Emby-Authentication) - Use Emby to authenticate users on Organizr

***
### Webserver Authentication 
**Organizr** features webserver authentication through Nginx.  Fully customizable with multiple rules.
[See Instructions](https://github.com/causefx/Organizr/wiki/Authentication---Server-Based)

***
### Browser [Cookie] Authentication 
**Organizr** features browser authentication through Nginx using Cookies.
[See Instructions](https://github.com/causefx/Organizr/wiki/Authentication-%7C-Cookie-Based)