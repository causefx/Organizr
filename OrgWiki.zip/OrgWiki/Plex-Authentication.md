# Enable Plex Authentication 

1. Go to Settings > Advanced Settings > Authentication tab
2. 'Which databases should be used to allow login' = Organizr & Backend
3. 'Select backend to use' = Plex
4. 'Create Accounts As Needed' = leave it with the default value
5. Enter your PMS username/password
6. Save

