# Welcome to the Organizr wiki!
The wiki is a work in progress. As it is currently in an unfinished state, some information may be unavailable or in a barebones condition.

## Requirements
1. Webserver - Apache or Nginx
2. PHP 5.6+
   * PDO
   * PDO_SQLITE
   * SQLITE3 [For Chat]
   * FOPEN
   * SimpleXML
   * PHP-ZIP
   * OPENSSL
   * MAIL [Used for resetting passwords]
   * CURL [For Plex & Emby Logins]
