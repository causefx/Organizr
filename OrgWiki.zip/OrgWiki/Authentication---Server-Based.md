# NGINX
This guide assumes that you have Organizr already running under NGINX.

Server Authentication will allow you to secure any/all location blocks, only allowing authenticated Organizr users or administrators access.
## How to create an authorization block on V1


Place a new location block under your server config like this:

**Admin**
```
location /auth-admin {
                internal;
                proxy_pass https://[my domain]/auth.php?admin;
                proxy_pass_request_body off;
                proxy_set_header Content-Length "";
                proxy_set_header X-Original-URI $request_uri;
}
```
**User**
```
location /auth-user {
                internal;
                proxy_pass https://[my domain]/auth.php?user;
                proxy_pass_request_body off;
                proxy_set_header Content-Length "";
                proxy_set_header X-Original-URI $request_uri;
}
```

**Location Block Name [location /auth-admin]** - This can be anything you want.  Define to something that makes sense for you.  We will be calling this later in our reverse proxy blocks.

**rewrite code** - The line always has to start with this: `rewrite ^ /auth.php?` after that you can then add either:
* **admin** - Only allows Admins to access the block/page.
* **user** - Only allows logged in users to access the block/page.

After that you also have another optional argument you can add which is `ban`, this option allows you to not allow access to certain users.  Make sure to separate each username with a comma and do not include any spaces.  It also must be prefixed by a `&` symbol.


You may create as many authorization blocks as you need, one for admins only, i.e. auth-admin.  Only for any logged in users... etc...

**Docker**

If you use a docker container, the location block needs look like this:
 ```
location /auth-admin {
internal;
proxy_pass http://[docker/hostIP]:[port]/auth.php?admin;
proxy_set_header Content-Length "";
}
```

## How to include the authorization block in a reverse proxy on V1
All you need to do is include one line per reverse proxy block as the very first line:
`auth_request /auth-admin;` Where **/auth-admin** is the name of the authorization block you made.

Here is a sample of a reverse proxy with admin access only:
```
        location /[SERVICE] {
                auth_request /auth-admin;
                proxy_pass http://[IP]:[PORT];
                add_header X-Frame-Options "SAMEORIGIN";
                proxy_set_header Host $host;
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        }
```
Here is a sample of a reverse proxy with user access:
```
        location /[SERVICE] {
                auth_request /auth-user;
                proxy_pass http://[IP]:[PORT];
                add_header X-Frame-Options "SAMEORIGIN";
                proxy_set_header Host $host;
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        }
```

***
## How to create an authorization block on V2

Place the location block under your server config like this:
```
location ~ /auth-(.*) {
	internal;
	rewrite ^/auth-(.*) /api/?v1/auth&group=$1;
}
```

#### To utilize the block add "auth_request /auth-x;" within your location block, where x=OrgV2 group_id
```
auth_request /auth-0;   #=Admin
auth_request /auth-1;   #=Co-Admin 
auth_request /auth-2;   #=Super User 
auth_request /auth-3;   #=Power User 
auth_request /auth-4;   #=User
auth_request /auth-998; #=Logged In
auth_request /auth-999; #=Guest
auth_request off;       #=Bypass Organizr login requirement (i.e. for Ombi)
```

**Docker**

If you use a docker container, the location block needs look like this:

```
location ~ /auth-(.*) {
        internal;
        proxy_pass http://[docker/hostIP]:[port]/api/?v1/auth&group=$1;
        proxy_set_header Content-Length "";
}
```

## Subdomain

For subdomains, add this to the subdomain server block.  
```
location ~ ^/auth-(.*) {
    ## Has to be local ip or local DNS name
    proxy_pass https://web.home.lab/api/?v1/auth&group=$1;
    proxy_pass_request_body off;
    proxy_set_header Content-Length "";
    
}
```

## How to include the authorization block in a reverse proxy on V2
All you need to do is include one line per reverse proxy block as the very first line:
`auth_request /auth-0;` Where **/auth-0** is the access level for admin.

Here is a sample of a reverse proxy with admin access:
```
        location /[SERVICE] {
                auth_request /auth-0;
                proxy_pass http://[IP]:[PORT];
                add_header X-Frame-Options "SAMEORIGIN";
                proxy_set_header Host $host;
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        }
```

***
## Custom Error Pages
Set anywhere in your NGINX config:  

### V1

`error_page 400 401 402 403 404 405 408 500 502 503 504 /error.php?error=$status;`

### V2
`error_page 400 401 402 403 404 405 408 500 502 503 504  $scheme://$server_name/?error=$status;`

With redirect

`error_page 401 $scheme://$server_name/?error=$status&return=$request_uri;`

`error_page 400 402 403 404 405 408 500 502 503 504  $scheme://$server_name/?error=$status;`

##### Docker
You need to add this in your config to make error pages work. Dont recommended to make it domain-wide, adding it for certain locations (such as sonarr, radarr) does the trick.
```
proxy_intercept_errors on;
```

# Caddy

Using Caddy and reauth you can accomplish the same using the following block:
```
  reauth {
    path /sonarr   # location that requires reauth
    # path /glances   # other directories can be listed
    #
    # if someone is not authorized for a page, send them here instead
    failure redirect target=https://<your_domain>/

    upstream url=https://<your_domain>/api/?v1/auth&group=<group_id>,cookies=true
  }
```

# Traefik

You can use Traefik's auth-forward feature to do the same.

Example docker-compose.yml block for Organizr:
```
services:
  organizr:
    image: organizrtools/organizr-v2
    environment:
      - TZ
      - PUID=${USER_UID}
      - PGID=${USER_GID}
    labels:
      - "traefik.enable=true"
      - "traefik.organizr.frontend.rule=Host: www.your_domain.com"
      - "traefik.organizr.port=80"
    depends_on:
      - traefik
```

Example service that depends on user being authenticated to Organizr:
```
services:
  nzbget:
    image: linuxserver/nzbget
    environment:
      - TZ
      - PUID=${USER_UID}
      - PGID=${USER_GID}
    labels:
      - "traefik.enable=true"
      - "traefik.frontend.rule=Host: nzbget.your_domain.com"
      - "traefik.frontend.auth.forward.address=http://organizr/api/?v1/auth&group=1"
      - "traefik.port=6789"
    depends_on:
      - traefik
      - organizr
```