# Using Organizr

***

### Creating Tabs
[See Instructions](https://github.com/causefx/Organizr/wiki/Tab-Creation)

### Enable Homepage/Landing Page
[See Instructions](https://github.com/causefx/Organizr/wiki/Optional-Homepage)