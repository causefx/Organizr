## Tab Creation

When you, for the first time, navigate to ``Settings -> Edit Tabs``, you will be presented with a mostly-blank page.

First, hit ``New Tab`` to begin creating your tabs.

### Fields

``Name``: The Name of Your Tab

``URL``: URL for the service's location. For example,
* When using relative paths or subdirectories: `/sonarr` (instead of `example.com/sonarr`)
* When using subdomains: `https://sonarr.example.com/`

``Icon URL``: When you hit the button ``View Icons``, the page will extend downward, showing you the built-in icons. When you hover over one you can see the "url" of that icon:

    images/organizr-load-w-thick.gif

When you click on an icon, it will send the text of the link to your clipboard, shrink the icons, all to allow you to input the image's url.

``Icon``: Font Awesome Icon

``Default``: Checking this option will make this tab and its content, basically, be your "homepage". (SEE ALSO [Optional-Homepage](https://github.com/causefx/Organizr/wiki/Optional-Homepage))

``Active``: Checking this option will activate the tab to appear on your page

``User``: This option enables this tab for Admins and Users but not Guests

``Guest``: This option enables the tab for Admin, Users and Guests

``No iFrame``: This option makes it so when you click the tab it will open in a new window (Used for apps that block iFrames)

#### NOTE

Once your login cookies expire, you will need to login again to view all of your restricted content.

If you aren't logged in you or if any guests land on your Organizr Page, you and they will only see your guest enabled tabs,
