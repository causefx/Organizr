# [Plex SSO](https://github.com/causefx/Organizr/wiki/Plex-SSO)

# [Ombi SSO](https://github.com/causefx/Organizr/wiki/Ombi-SSO)

# Tautulli *Coming Soon...*