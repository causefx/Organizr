# NGINX

This guide assumes that you have Organizr previously running under NGINX and you are using it as reverse proxy.
It is essential for your services to be located as a subdirectory.

First, set your chosen cookie password in Organizr: 
<img src="https://cloud.githubusercontent.com/assets/10834935/23854004/43fa89e2-07e7-11e7-9b74-03c583924997.png"></img>

Then insert into each NGINX proxy block:

    location /[SERVICE] {
        if ($cookie_cookiePassword != "TestPassword") { return 403; }
        add_header X-Frame-Options "SAMEORIGIN";
        proxy_pass http://[IP]:[PORT];
    }

Once configured, ensure you first logout of Organizr.