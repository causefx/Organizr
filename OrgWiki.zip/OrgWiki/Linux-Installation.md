# Auto Installer for Linux (Debian/Ubuntu/Raspbian/Centos)

We've got an auto installer script to get you up and running in a few mins.

### How do I run the script? [Debian/Ubuntu/Raspbian]
1. `sudo apt-get install git`
2. `sudo git clone https://github.com/elmerfdz/OrganizrInstaller /opt/OrganizrInstaller`
3. `cd /opt/OrganizrInstaller/ubuntu/oui`
4. `sudo bash ou_installer.sh`

![menu](https://i.imgur.com/VSHasOs.png)

5. Select option **4**, this will install all Organizr requirements (including Nginx & PHP). 
It also creates the Nginx vhost config file for you. Once completed you can edit the Nginx vhost file as you please.

***Note**: Debian 8 users, If you've got PHP 5.x installed, please uninstall it first and then launch the script, select option 6, followed by option 1 under Utilities 'Debian 8.x PHP7 fix', once done, go back to the main menu and run option 4. This step isn't required for **Debian 9**.x users.

![utilities](https://i.imgur.com/iRMbif9.png)

### How do I run the script on CentOS? 

1. `sudo yum install git`
2. `sudo git clone https://github.com/elmerfdz/OrganizrInstaller /opt/OrganizrInstaller`
3. `cd /opt/OrganizrInstaller/centos/oci`
4. `sudo bash oc_installer.sh`
5. Select option **4**, this will install all Organizr requirements (including Nginx & PHP). 
It also creates the Nginx vhost config file for you. Once completed you can edit the Nginx vhost file as you please.

![menu](https://i.imgur.com/7nSnAXl.png)

#### Tested on version?
- CentOS 7

# Manual Install on Linux 
## GIT
1. `cd` to the parent directory of where you want to place Organizr.
2. Run `sudo git clone https://github.com/causefx/Organizr`
3. Run `sudo chown -R www-data:www-data /path/to/Organizr`
4. Open your Web Browser to the location where you placed the file e.g. `http://localhost/Organizr`

## ZIP Download
1. Run `sudo wget https://github.com/causefx/Organizr/archive/master.zip`
2. Run `sudo unzip master.zip -d /path/to/web/`
3. Run `sudo chown -R www-data:www-data /path/to/Organizr`
4. Open your Web Browser to the location where you placed the file e.g. `http://localhost/Organizr`

## Install Optional Components
1. Run `sudo apt-get install php7.0-zip`
2. Run `sudo apt-get install php7.0-xml`

Verify that everything is green by going to domain.com/check.php