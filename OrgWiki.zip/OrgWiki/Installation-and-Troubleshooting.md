# Organizr Installation & Troubleshooting


## V2 Disclaimer
All guides referring to the Release page is currently giving you V1, to get V2 download the zip from the [v2-develop](https://github.com/causefx/Organizr/archive/v2-develop.zip) branch

All guides reffering to `git clone https://github.com/causefx/Organizr`gives you V1, replace with this: `git clone -b v2-develop https://github.com/causefx/Organizr`for V2


***
### Windows Installation 

[See Normal Instructions](https://github.com/causefx/Organizr/wiki/Windows-Installation:--Nginx-%7C-PHP-%7C-Organizr)

[See Advanced Instructions](https://github.com/causefx/Organizr/wiki/Windows-Installation---Advanced)

#### Caddy Installation for Windows
[See Instructions](https://github.com/causefx/Organizr/wiki/Caddy-Installation)

***
### Linux Installation  
[See Instructions](https://github.com/causefx/Organizr/wiki/Linux-Installation)

***
### Docker and NAS Container Installation (Docker, Synology, FreeNAS)
[See Instructions](https://github.com/causefx/Organizr/wiki/NAS-and-Docker-Installation)

***
### Mac Installation 
**Organizr** instructions coming soon.