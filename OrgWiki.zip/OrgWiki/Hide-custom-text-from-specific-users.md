To display text only for specific user groups, refer to the below snippet and insert into a custom homepage item:

    <script>
        if(activeInfo.user.groupID !== 999){
            var cssSettings = `
                .hidden-for-non-guest {
                    display: none;
                }
            `;
            $('#guest-css').html(cssSettings);
        }
    </script>
    <style id="guest-css"></style>
    <div class="hidden-for-non-guest">
        <h1>You're a guest.  Please log in!</h1>
    </div>
    This is text everyone sees.